<form name="register"  action="preg.php" method="POST" id="register" style="font-family:ff-meta-web,Arial,sans-serif;text-align:justify;line-height:25px; font-size:12px;">
    <label style="margin-right:30px;"> <b> Name : </b></label>

    <input type="text" name="name" id="name" style="width:200px;" /> 
    <br /> <br />

    <label> <b> User Name : </b></label>
    <input type="text" name="username" id="username" style="width:200px;" /> <br/><br/>
    <label> <b> Password : </b></label> 
    <input type="password" name="password" id="password" style="width:200px;" />
    <br /> <br /> 
    <label> <b>Confirm Password : </b></label> 
    <input type="password" name="cpassword" id="cpassword" style="width:200px;" />
    <br /> <br /> 
    <input type="submit" name="submit" value="Submit" style="background-color:#005797; color:#fff; border:0px; padding:5px 10px;" /> 

    </form>