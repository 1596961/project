<html>
<head>
	<style type="text/css">
	body{background-image:url("k.jpg");
	background-size:1550px 800px;}
	.l{top:900px;left:1000px;width:300px;height:250px;}
	.lk{width:150px;height:250px;}
	</style>
</head>
<body font-size:40px bgcolor="lightsesgray">
	<h1 align="center"><br>LOGIN</h1>
	<table align="center" class="l" cellspacing="60">
	<tr><td><p><a href="adminhome.php" target="_top"><img src="a2.jpg" class="lk"/></a><h1>Administrator<h1></p></td>
	<td><p><a href="userlogin.php" target="_top"><img src="user.png" class="lk"/></a><h1>User</h1></p></td>
	</table>
	<center><form align="center" action="home.php"><input type="submit" value="HOME"/></form><center>
</body>
</html>