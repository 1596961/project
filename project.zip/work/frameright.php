<html>
	<head>
		<style type="text/css">
			body{background-color:violet;}
			.pic{position:absolute;
			     top:0px;
			     left:0px;width:455px;height:478px;font-size:1.5em}
		</style>
	</head>
	<body>
	<table border="1" class="pic">
	<tr><td align="center" bgcolor="cyan"><a href="home.php" target="_top" >HOME</a></td></tr>
	<tr><td align="center" bgcolor="fcc66"><a href="user.php" target="_top">REGISTER</a></td></tr>
	<tr><td align="center" bgcolor="009ff2874a6"><a href="logint.php" target="_top">LOGIN</a></td></tr>
	</table>
	</body>
</html>
