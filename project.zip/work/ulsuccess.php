<html>
<head>
<style type="text/css">
			.img2{position:absolute;top:10px;left:500px;width:509px;height:404px}
		</style>
	</head>
</head>
<body bgcolor="grey">
<form align="center" action="home.php">
<p><img src="lock.jpg" class="img2"/></p><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<input type="submit" value="HOME">
</form>
</body>
</html>