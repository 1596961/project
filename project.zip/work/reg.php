<html>
<head>
<style>
.img2{position:absolute;top:75px;left:650px;width:225px;height:225px}
.1{position:absolute;top:125px;left:570px;width:225px;height:225px}
</style>
<body>
<p><img src="a3.jpg" class="img2"/></p>
<center>
<h3><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>Registration Success</h3>
<form action="home.php" class="1">
<input type="submit" value="close"></form>
<center>
</body>
</html>