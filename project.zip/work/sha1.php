<html>
<form method="POST" action="sha256.php">
enter a number or string
<input type="username" name="uid" required>
<!--<input type="password" name="pwd" required>-->
<input type="submit" value="submit" name="check">
</form>
</html> 