<html>
	<head>
		<style type="text/css">
			.img2{position:absolute;top:0px;left:0px;width:1050px;height:480px}
		</style>
	</head>
	<p><img src="a.jpg" class="img2"/></p>
</html>