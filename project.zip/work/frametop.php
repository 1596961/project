<html>
	<head>
	<style type="text/css">
		body{background-image:url("hi.jpg");
		     background-size:1550px 290px;
	             background-repeat:repeat-x;}
	h1.center{color:;text-align:center;font-size:90px;top:290px;left:500px;}
	</style>
	<body bgcolor="#DAF7A6">
	<h1 class="center">Authentication By Encrypted Negative Password</h1>
	</body>
	</style>
	</head>
</html>