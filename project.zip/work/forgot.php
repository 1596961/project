<html>
<body bgcolor="">
<form action="dbforgot.php" method="POST">
<center><br><br><br>
Enter UserId   &nbsp;<input type="text" placeholder="Enter UserId" name="uid" required><br><br>
<input type="submit" value="Submit"/> 
</form>
</body>
</html>