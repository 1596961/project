<html>
	<head>
		<frameset rows="30%,60%">
		<frame name="top" src="frametop.php">
		<frameset cols="70%,30%">
		<frame name="left" src="frameleft.php">
		<frame name="right" src="frameright.php">
		</frameset>
		</frameset>
	</head>
</html>