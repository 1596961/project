<html>
<head>
	<style type="text/css">
	body{background-image:url("b9.jpg");
	background-size:1550px 800px;}
	.l{top:1000px;left:1200px;width:300px;height:300px;}
	.lk{left:1200px;width:150px;height:200px;}
	</style>
</head>
<body font-size:40px >
<br><br><br>
	<h1 align="center">ADMIN INFO</h1>
	<table align="center" class="l" cols=2 cellspacing="50">
	<td><p><a href="users.php"><img src="user.jpg" class="lk"/></a><h1>User Details</h1></p></td>
	</table>
</body>
</html>