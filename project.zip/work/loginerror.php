<html>
<head>
<body bgcolor="pink">
<form align="center" method="post" action="adminhome.php"><br><br>
<h1>Invalid login please enter valid details<h1>
<input type="submit" value="ok"></form>
</body>
</head>
</html>