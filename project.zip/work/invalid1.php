<html>
<head>
<body bgcolor="pink">
<form align="center" method="post" action="ulogin.php"><br><br><br>
<h1>Invalid login please enter valid details<h1>
<input type="submit" value="Back"></form>
</body>
</head>
</html