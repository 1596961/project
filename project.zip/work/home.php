<html>
<head>
<style>
body{background-image:url("8.jpg");
		     background-size:1550px 1080px;
	             background-repeat:repeat-x;}
h1.center{color:black;text-align:center;font-size:75px;top:290px;left:500px;}
.img2{position:absolute;top:225px;left:0px;width:850px;height:520px}
.pic{position:absolute;
			     top:400px;
			     left:910px;width:380px;height:50px;font-size:1.5em}
.pic1{position:absolute;
			     top:460px;
			     left:910px;width:380px;height:50px;font-size:1.5em}
</style>
<body bgcolor="ff9999">
	<h1 class="center">Authentication By Encrypted Negative Password</h1>
	<p><img src="a.jpg" class="img2"/></p>
	<table border="0" class="pic">
	<tr><td align="center" bgcolor="#a0a0a0"><a href="register.php" target="_top" >REGISTER</a></td></tr></table><br><br><br><br><br>
	<table border="0" class="pic1">
	<tr><td align="center" bgcolor="#a0a0a0"><a href="login.php" target="_top">LOGIN</a></td></tr></table>
	</body>
	</style>
	</head>
</html>